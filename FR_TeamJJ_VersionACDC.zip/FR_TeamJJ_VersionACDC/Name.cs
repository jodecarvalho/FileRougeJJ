﻿namespace FR_TeamJJ_VersionACDC
{
    public class Name
    {
    }
}