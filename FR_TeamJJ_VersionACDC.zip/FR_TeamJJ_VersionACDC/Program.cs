﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace FR_TeamJJ_VersionACDC
{
    class Program
    {
        static void Main(string[] args)
        {
            var path = @"..\agents.txt";
            var pathQuestion = @"..\question.txt";
            Admin Joaquim = new Admin("AdminJo", "Joaquim");
            Admin Jerome = new Admin("AdminJerome", "Jérôme");
        START:
            Console.Clear();
            Console.WriteLine("Identification admin\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\nSaisir votre Identifiant");
        
            var adminSaisi = Console.ReadLine();
           
            
                if (adminSaisi == Joaquim.IdAdmin)
                {
                    Console.WriteLine($"Bonjour {Joaquim.Name} !");
                    
                }
                else if (adminSaisi == Jerome.IdAdmin)
                {
                    Console.WriteLine($"Bonjour {Jerome.Name} !");
                }
                else
                {
                    Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n Erreur de saisi ou vous ne disposez pas des droits nécessaire. \n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    Console.ReadKey();
                    goto START;
                }
            Console.ReadKey();

        MENU:
            Console.Clear();
            Console.WriteLine("Menu\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
            Console.WriteLine("1-Ajouter un Agent\n2-Voir les Agents\n3-Ajouter une Question\n4-Voir les Questions\n5-Quitter");
            var choixMenu = Console.ReadLine();
            int choixMenuConvert;
            bool convert = int.TryParse(choixMenu, out choixMenuConvert);
            switch (choixMenuConvert) 
            {
                case 1:
                    goto AddAgent;
                    

                case 2:
                    goto VoirAgent;

                case 3:
                    goto AddQuestion;

                case 4:
                    goto VoirQuestion;

                case 5:
                    goto Finish;
                default:
                    goto MENU;
            }



        AddAgent:
            Console.Clear();
            Console.WriteLine("Ici on créera un Agent ! Mais pas deux...\n");
            
            Console.WriteLine("Saisir son Nom");
            var saisiNom = Console.ReadLine();
            Console.WriteLine("Saisir son Prenom");
            var saisiPrenom = Console.ReadLine();
            Console.WriteLine("Saisir sa Date de Naissance");
            var saisiDateNaissance = Console.ReadLine();


            
            using (StreamWriter sw = File.AppendText(path))
            {
                sw.WriteLine($"Nom : {saisiNom.ToUpper()}, Prenom : {saisiPrenom}, Né(e) le : {saisiDateNaissance} ");
            }

          
            
            Console.WriteLine($"Vous avez créé {saisiNom.ToUpper()} {saisiPrenom} né(e) le {saisiDateNaissance}.");
            Console.ReadKey();
            goto MENU;

        VoirAgent:
            Console.Clear();
            Console.WriteLine("Ici on regardera la liste des Agents ! Mais pas aujourd'hui");

            using (StreamReader sr = new StreamReader(path))
            {
                string line;

                //Tant que ma condition est vraie : je continue 
                while ((line = sr.ReadLine()) != null)
                {
                    Console.WriteLine(line);
                }
            }

            Console.ReadKey();
            goto MENU;

        AddQuestion:
            Console.Clear();
            Console.WriteLine("Ici on créera les questions, peut etre.");
            Console.WriteLine("Saisir la difficulté (J/C/E) de la Question et son Numero");
            var saisiNbQuestion = Console.ReadLine();
            Console.WriteLine("Saisir le libellé de la question");
            var saisiQuestion = Console.ReadLine();
            Console.WriteLine("Saisir sa 1ere Reponse");
            var saisiReponse1 = Console.ReadLine();
            Console.WriteLine("Saisir sa 2e Reponse");
            var saisiReponse2 = Console.ReadLine();
            Console.WriteLine("Saisir sa 3e Reponse");
            var saisiReponse3 = Console.ReadLine();



            using (StreamWriter sw = File.AppendText(pathQuestion))
            {
                sw.WriteLine($"{saisiNbQuestion.ToUpper()} : {saisiQuestion} \nRep 1 : {saisiReponse1}\nRep 2 : {saisiReponse2}\nRep 3 : {saisiReponse3} \n");
            }
            Console.WriteLine($"Vous avez créé la question suivante : \n{saisiNbQuestion.ToUpper()} : {saisiQuestion} \nRep 1 : {saisiReponse1}\nRep 2 : {saisiReponse2}\nRep 3 : {saisiReponse3} ");
            Console.ReadKey();
            goto MENU;

        VoirQuestion:
            Console.Clear();
            using (StreamReader sr = new StreamReader(pathQuestion))
            {
                string line;

                //Tant que ma condition est vraie : je continue 
                while ((line = sr.ReadLine()) != null)
                {
                    Console.WriteLine(line);
                }
            }
            Console.ReadKey();
            goto MENU;

        Finish:
            Console.Clear();
            
        }
    }
}
