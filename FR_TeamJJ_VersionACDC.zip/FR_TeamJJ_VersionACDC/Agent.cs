﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FR_TeamJJ_VersionACDC
{
    class Agent 
    {
    
        public string Name { get; set; }
        public string FirstName { get; set; }
        public string DateNaissance { get; set; }

        public Agent(string Name, string FirstName, string DateNaissance)
        {
            this.Name = Name;
            this.FirstName = FirstName;
            this.DateNaissance = DateNaissance;
        }

       


    }
}
